DEMO is here:
https://calm-spire-58966.herokuapp.com/


To run the app:

Install  node.js and npm
in the terminal type:

npm install

node app.js


Then you can open your browser to localhost:8000


